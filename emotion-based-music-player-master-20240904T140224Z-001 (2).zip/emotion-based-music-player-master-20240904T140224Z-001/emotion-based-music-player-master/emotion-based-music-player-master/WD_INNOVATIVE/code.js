
var songrun=false;
var count=1;
var mod=1;
var path=["songs\\Minikki Minikki.mp3"
,"songs\\Innum-Konjam-Neram.mp3"
,"songs\\Ennodu-Nee-Irundhal.mp3"
,"songs\\Idhayam-Love-(Megamo-Aval)-MassTamilan.com.mp3"
,"songs\\Nee-Kavithaigala.mp3"
,"songs\\Oru-Naalil---Composer's-Dream-Mix.mp3"
,"songs\\Ava-Enna-Enna-MassTamilan.com.mp3"
,"songs\\Poi-Vazhva.mp3"
,"songs\\Kanave-Kanave-MassTamilan.com.mp3"
,"songs\\Poo-Nee-Poo.mp3"
,"songs\\Edhirthu-Nil.mp3"
,"songs\\Mun-Sellada.mp3"
,"songs\\Porkkalam-Tamil-Rap.mp3"
,"songs\\Maara-Theme-MassTamilan.io.mp3"
,"songs\\Poradalam.mp3"
,"songs\\Maamadurai-MassTamilan.dev.mp3"
,"songs\\Padichu-Pathen.mp3"
,"songs\\Macha-Kanni.mp3"
,"songs\\Pistah.mp3"
,"songs\\Machi-Open-The-Bottle.mp3"];

var sname=["Minikki Minnikki",
"Innum-Konjam-Neram",
"Ennodu-Nee-Irundhal",
"Idhayam-Love-(Megamo-Aval)-MassTamilan.com",
"Nee-Kavithaigala",
"Oru-Naalil---Composer's-Dream-Mix",
"Ava-Enna-Enna-MassTamilan.com",
"Poi-Vazhva",
"Kanave-Kanave-MassTamilan.com",
"Poo-Nee-Poo",
"Edhirthu-Nil",
"Mun-Sellada",
"Porkkalam-Tamil-Rap",
"Maara-Theme-MassTamilan.io",
"Poradalam",
"Maamadurai-MassTamilan.dev",
"Padichu-Pathen",
"Macha-Kanni",
"Pistah",
"Machi-Open-The-Bottle"
];

var sd=["Artist: Vikram,G.V.Prakash<br>Movie: Thangalan<br>Released: 2024",
"Artists: A.R.Rahman<br>Featured artists:Dhanush<br>Movie:Mariyaan<br>Released: 2017"
,"Artists: A.R.Rahman<br>Movie: I<br>Released: 2015"
,"Artist: Pradeep Kumar,Santhosh Narayanan,Pradeep<br>Movie: Meyaadha Maan<br>Released: 2017<br>"
,"Artist: Dhibu Ninan Thomas<br>Movie: Maragatha Naanayam<br>Released: 2017"
,"Artists: Yuvan Shankar Raja<br>Movie: Pudhupettai<br>Released: 2006<br>Composer(s):"
,"Artist: Harrish Jayaraj<br>Released: 2008<br>Movie: Vaaranam Aayiram"
,"Artist: Santhosh Narayanan<br>Movie: Manithan<br>Released: 2016"
,"Artist: Vikram,Anirudh RaviChandran<br>Movie: David<br>Released: 2013"
,"Artist: Anirudh RaviChandran<br>Movie: Monnu<br>Released: 2012"
,"Artist: KK<br>Movie: Shab<br>Released: 2017"
,"Artist: KK<br>Movie: Shab<br>Released: 2017"
,"Artist: KK<br>Movie: Shab<br>Released: 2017"
,"Artist: KK<br>Movie: Shab<br>Released: 2017"
,"Artist: KK<br>Movie: Shab<br>Released: 2017"
,"Artist: KK<br>Movie: Shab<br>Released: 2017"
,"Artist: KK<br>Movie: Shab<br>Released: 2017"
,"Artist: KK<br>Movie: Shab<br>Released: 2017"

,"Artist: Arijit Singh<br>Movie: Shab<br>Released: 2017"
,"Artists: Arijit Singh, Shashaa Tirupati<br>Movie: Half Girlfriend<br>Released: 2017<br>Written: 2001 (lyrics)<br>Lyricist(s): Manoj Muntashir<br>Composer(s): Mithoon"];

var bool=[];
for(var i=0; i<sd.length; i++)
	bool[i]=false;

var icon=["images\\\\1.png",
"images\\\\2.png",
"images\\\\3.png",
"images\\\\4.png",
"images\\\\5.png",
"images\\\\6.png",
"images\\\\7.png",
"images\\\\8.png",
"images\\\\9.png",
"images\\\\10.png",
"images\\\\11.png",
"images\\\\12.png",
"images\\\\13.png",
"images\\\\14.png",
"images\\\\15.png",
"images\\\\16.png",
"images\\\\17.png",
"images\\\\18.png",
"images\\\\19.png",
"images\\\\20.png"];

var mood = [
    ["1", "2", "3"], ["4", "5"], ["6", "7", "8"], 
    ["9", "10"], ["11", "12"], ["13", "14"], 
    ["15", "16"], ["17", "18"], ["19", "20"],
    ["21", "22"], ["23", "24"], ["25", "26"]
];

var mmm = [
    "1.png", "1.png", "1.png", 
    "2.png", "2.png", "3.png", 
    "3.png", "3.png", "4.png", 
    "4.png", "5.png", "5.png"
];


var songs=new Array(icon.length);
for (var i = 0; i<icon.length; i++) {
	songs[i]=new Array(4);
	songs[i][0]=path[i];
	songs[i][1]=sd[i];
	songs[i][2]=icon[i];
	songs[i][3]=mmm[i];
	console.log(songs[i][0]);
	console.log(songs[i][1]);
	console.log(songs[i][2]);
	var ins=document.createElement("div");
	ins.id='b'+i;
	//ins.onclick=function(){
	//next(this);
  	//};
	ins.setAttribute("class", "song");
	document.body.appendChild(ins);
	document.getElementById('b'+i).innerHTML='<div id="pic" style=\'background-image: url(\"'+songs[i][2]+'\");\'>  <input type="button" id="'+"a"+i+'" class="play" > <input type="button" id="'+"c"+i+'" class="add">  </div><div id="data"><br><br>'+songs[i][1]+'</div>';
	document.getElementById('a'+i).onclick=function(){
		play(this);
	};
	document.getElementById('c'+i).onclick=function(){
		addq(this);
	};	
}




function setmod(elem){
	mod=elem.value;
	if(!songrun){
		if(mod==2)
			getTime();
		if(mod==3)
			rand_play();
	}
}

function play(elem){
	console.log(elem.id);
	var x=elem.id.charAt(1);
	var z=songs[x][0];
	document.getElementById("sname").innerHTML=sname[x];
	document.getElementById("sel").src= z;
	document.getElementById("main_slider").load();
	document.getElementById("main_slider").play();
	document.getElementById("emoji").style.backgroundImage="url('"+songs[x][3]+"')";
	songrun=true;

}

var eqc=1;
var sqc=1;

function addq(elem){
	console.log(elem.id);
	var x=elem.id.charAt(1);
	if(!songrun){
		var z=songs[x][0];
		document.getElementById("sname").innerHTML=sname[x];
		document.getElementById("sel").src= z;
		document.getElementById("main_slider").load();
		document.getElementById("main_slider").play();
		document.getElementById("emoji").style.backgroundImage="url('"+songs[x][3]+"')";
		songrun=true;		
		return;
	}
	if(bool[x]==true)
		return;
	
	bool[x]=true;
	var l=document.createElement("label");
	l.id="e"+eqc;
	l.name=x;
	l.innerHTML=sname[x]+"<br>";
	//var text=document.createTextNode(sname[x]+"<br>");
	//l.appendChild(text);
	document.getElementById("queue").appendChild(l);
	eqc=eqc+1;
}

function nextsong(){
	if(sqc==eqc){
				alert("Queue is empty.");
				return;
		}
		var elem=document.getElementById("e"+sqc);
			var xa=elem.name;
			var pa=songs[xa][0];
			bool[xa]=false;
			document.getElementById("sname").innerHTML=sname[xa];
			document.getElementById("sel").src= pa;
			document.getElementById("main_slider").load();
			document.getElementById("main_slider").play();
			document.getElementById("emoji").style.backgroundImage="url('"+songs[xa][3]+"')";
			
			songrun=true;
			document.getElementById("queue").removeChild(elem);	
			sqc=sqc+1;

}

function next_in_Q(){
			songrun=false;
			if(sqc==eqc){
				alert("Queue is empty.");
				return;
			}
			var elem=document.getElementById("e"+sqc);
			var xa=elem.name;
			var pa=songs[xa][0];
			document.getElementById("sname").innerHTML=sname[xa];
			document.getElementById("sel").src= pa;
			document.getElementById("main_slider").load();
			document.getElementById("main_slider").play();
			document.getElementById("emoji").style.backgroundImage="url('"+songs[xa][3]+"')";
			songrun=true;
			document.getElementById("queue").removeChild(elem);	
			sqc=sqc+1;
			}

function rand_play(){
	var index=Math.random()*path.length;
	index=parseInt(index);
	var pa=songs[index][0];
	document.getElementById("sname").innerHTML=sname[index];
	document.getElementById("sel").src= pa;
	document.getElementById("main_slider").load();
	document.getElementById("main_slider").play();
	document.getElementById("emoji").style.backgroundImage="url('"+songs[index][3]+"')";
	songrun=true;

}
function moody(val){
	var index=Math.random()*mood[val].length;
	index=parseInt(index);
	var pa=songs[mood[val][index]-1][0];
	document.getElementById("sname").innerHTML=sname[mood[val][index]-1];
	document.getElementById("sel").src= pa;
	document.getElementById("main_slider").load();
	document.getElementById("main_slider").play();
	document.getElementById("emoji").style.backgroundImage="url('"+songs[mood[val][index]-1][3]+"')";
	songrun=true;
}

async function getTime() {
                let value = await eel.getEmotion()();
                if(value=="angry")
                	moody(0);
                else if(value=="happy")
                	moody(1);
                else if(value=="sad")
                	moody(2);
                else
                	moody(3);
            }